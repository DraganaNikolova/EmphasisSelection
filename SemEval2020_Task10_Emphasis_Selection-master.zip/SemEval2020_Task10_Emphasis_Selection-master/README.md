# SemEval2020_Task10_Emphasis_Selection

HomePage: http://ritual.uh.edu/semeval2020-task10-emphasis-selection/

CodaLab: https://competitions.codalab.org/competitions/20815
